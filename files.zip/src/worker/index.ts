/**
 * Worker: polls connected accounts and stores MetricSnapshot rows.
 * Additionally, processes report schedules and sends emails for scheduled reports.
 */

import { Queue, Worker } from "bullmq";
import IORedis from "ioredis";
import prisma from "../lib/db";
import { fetchGoogleAdsMetrics } from "../lib/providers/googleAds";
import { fetchMetaAdsMetrics, listMetaAdAccounts } from "../lib/providers/metaAds";
import { fetchLinkedinAdsMetrics, listLinkedinAdAccounts } from "../lib/providers/linkedinAds";
import { sendReportEmail } from "../lib/email";
import dayjs from "dayjs";

const connection = new IORedis(process.env.REDIS_URL || "redis://localhost:6379");
const fetchQueue = new Queue("fetch-metrics", { connection });
const reportQueue = new Queue("run-report", { connection });

async function enqueueAllAccounts() {
  const accounts = await prisma.connectedAccount.findMany();
  for (const acc of accounts) {
    await fetchQueue.add("fetch", { accountId: acc.id, provider: acc.provider }, { attempts: 3, backoff: { type: "exponential", delay: 1000 } });
  }
}

async function enqueueDueReports() {
  const now = new Date();
  const due = await prisma.reportSchedule.findMany({
    where: {
      enabled: true,
      nextRun: { lte: now }
    }
  });
  for (const s of due) {
    await reportQueue.add("send", { scheduleId: s.id }, { attempts: 3, backoff: { type: "exponential", delay: 2000 } });
    // update nextRun per frequency (naive)
    let next = dayjs(s.nextRun);
    if (s.frequency === "daily") next = next.add(1, "day");
    else if (s.frequency === "weekly") next = next.add(1, "week");
    else if (s.frequency === "monthly") next = next.add(1, "month");
    await prisma.reportSchedule.update({ where: { id: s.id }, data: { nextRun: next.toDate() } });
  }
}

// Fetch worker
new Worker("fetch-metrics", async (job) => {
  const { accountId, provider } = job.data;
  const account = await prisma.connectedAccount.findUnique({ where: { id: accountId } });
  if (!account) throw new Error("account not found");

  if (provider === "google") {
    const res = await fetchGoogleAdsMetrics(accountId);
    if (res.ok && res.rows) {
      for (const r of res.rows) {
        await prisma.metricSnapshot.create({
          data: {
            connectedAccountId: account.id,
            date: new Date(),
            impressions: r.impressions,
            clicks: r.clicks,
            spendMicros: r.spendMicros ?? undefined,
            raw: r.raw
          }
        });
      }
    } else {
      console.error("google fetch error", res);
    }
  } else if (provider === "meta") {
    const acctList = await listMetaAdAccounts(account.accessTokenEnc);
    for (const adAcct of acctList) {
      const res = await fetchMetaAdsMetrics(account.accessTokenEnc, adAcct.account_id);
      if (res.ok && res.rows) {
        for (const r of res.rows) {
          await prisma.metricSnapshot.create({
            data: {
              connectedAccountId: account.id,
              date: new Date(),
              impressions: r.impressions,
              clicks: r.clicks,
              spendMicros: r.spendMicros ?? undefined,
              raw: r.raw
            }
          });
        }
      } else {
        console.error("meta fetch error", res);
      }
    }
  } else if (provider === "linkedin") {
    const accs = await listLinkedinAdAccounts(account.accessTokenEnc);
    for (const a of accs) {
      const urn = a.account || a.urn || a.id ? a.account || a.urn || `urn:li:sponsoredAccount:${a.id}` : null;
      if (!urn) continue;
      const res = await fetchLinkedinAdsMetrics(account.accessTokenEnc, urn);
      if (res.ok && res.rows) {
        for (const r of res.rows) {
          await prisma.metricSnapshot.create({
            data: {
              connectedAccountId: account.id,
              date: new Date(),
              impressions: r.impressions,
              clicks: r.clicks,
              spendMicros: r.spendMicros ?? undefined,
              raw: r.raw
            }
          });
        }
      } else {
        console.error("linkedin fetch error", res);
      }
    }
  } else {
    console.warn("unknown provider", provider);
  }
}, { connection });

// Report worker
new Worker("run-report", async (job) => {
  const { scheduleId } = job.data;
  const schedule = await prisma.reportSchedule.findUnique({ where: { id: scheduleId } });
  if (!schedule) throw new Error("schedule not found");

  // Build query from filters - here we do a simple last N days or explicit date range
  const filters = schedule.filters as any || {};
  const dateFrom = filters.dateFrom ? new Date(filters.dateFrom) : dayjs().subtract(7, "day").toDate();
  const dateTo = filters.dateTo ? new Date(filters.dateTo) : dayjs().toDate();

  // Query metric snapshots for the schedule's client (or all clients for the user)
  const where: any = {
    date: { gte: dateFrom, lte: dateTo }
  };
  if (schedule.clientId) {
    // get connected accounts for that client
    const campaigns = await prisma.campaign.findMany({ where: { clientId: schedule.clientId } });
    const campaignIds = campaigns.map((c) => c.id);
    where.campaignId = { in: campaignIds.length ? campaignIds : ["__no_match__"] };
  } else {
    // user's all clients: filter by connectedAccounts owned by user
    const accs = await prisma.connectedAccount.findMany({ where: { userId: schedule.userId } });
    const accIds = accs.map((a) => a.id);
    where.connectedAccountId = { in: accIds.length ? accIds : ["__no_match__"] };
  }

  const snaps = await prisma.metricSnapshot.findMany({
    where,
    include: { connectedAccount: true, campaign: true },
    orderBy: { date: "asc" }
  });

  // Build CSV
  const lines = [
    ["date", "account", "campaign", "impressions", "clicks", "spend"].join(",")
  ];
  for (const s of snaps) {
    const date = s.date.toISOString().slice(0, 10);
    const accountName = s.connectedAccount?.displayName || s.connectedAccountId;
    const campaignName = s.campaign?.name || "";
    const imp = s.impressions || 0;
    const clicks = s.clicks || 0;
    const spend = s.spendMicros ? Number(s.spendMicros) / 1_000_000 : 0;
    lines.push([date, `"${accountName}"`, `"${campaignName}"`, String(imp), String(clicks), String(spend)].join(","));
  }
  const csv = lines.join("\n");

  // Send email to recipients
  const recipients = schedule.recipients.split(",").map((r) => r.trim()).filter(Boolean);
  const subject = `Scheduled Report: ${schedule.name} - ${new Date().toISOString().slice(0, 10)}`;
  const html = `<p>Attached is the scheduled report <strong>${schedule.name}</strong> for ${schedule.frequency} run.</p><p>Rows: ${snaps.length}</p>`;
  try {
    await sendReportEmail({
      to: recipients.join(","),
      subject,
      html,
      attachments: [{
        filename: `${schedule.name.replace(/\s+/g, "_")}_${new Date().toISOString().slice(0,10)}.csv`,
        content: csv
      }]
    });
    console.log("report sent", schedule.id, "to", recipients);
  } catch (err: any) {
    console.error("report send failed", err?.message || err);
    throw err;
  }
}, { connection });

(async function scheduleLoop() {
  // initial enqueue of data-fetch jobs
  await enqueueAllAccounts();
  // periodic account fetch every 15 minutes
  setInterval(enqueueAllAccounts, 1000 * 60 * 15);

  // schedule checker runs every minute to enqueue report jobs
  await enqueueDueReports();
  setInterval(enqueueDueReports, 1000 * 60);
})();