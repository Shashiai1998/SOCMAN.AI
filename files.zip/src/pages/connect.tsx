import React, { useEffect, useState } from "react";
import axios from "axios";
import { useSession, signIn } from "next-auth/react";

/**
 * Connect UI: choose client and start OAuth flow for providers. Session-aware.
 */

export default function ConnectPage() {
  const { data: session, status } = useSession();
  const [clients, setClients] = useState<any[]>([]);
  const [clientId, setClientId] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (status === "authenticated") loadClients();
  }, [status]);

  async function loadClients() {
    setLoading(true);
    try {
      const res = await axios.get(`/api/clients?userId=${encodeURIComponent((session as any)?.userId)}`).catch(() => ({ data: [] }));
      setClients(res.data || []);
    } finally { setLoading(false); }
  }

  if (status === "loading") return <div className="card">Loading session...</div>;
  if (status !== "authenticated") {
    return (
      <div className="card">
        <h2 className="h1">Connect accounts</h2>
        <p className="muted">Sign in to attach provider accounts to clients and start pulling metrics.</p>
        <div style={{ marginTop: 12 }}>
          <button className="btn btn-primary" onClick={() => signIn()}>Sign in</button>
        </div>
      </div>
    );
  }

  function start(provider: string) {
    const clientQuery = clientId ? `&clientId=${encodeURIComponent(clientId)}` : "";
    const userQuery = `?userId=${encodeURIComponent((session as any).userId)}`;
    window.location.href = `/api/oauth/start/${provider}${userQuery}${clientQuery}`;
  }

  return (
    <div>
      <h2 className="h1">Connect accounts</h2>
      <div className="muted">Attach a provider account to a client to keep data organized</div>

      <div style={{display:"flex",gap:12,marginTop:16,alignItems:"center"}}>
        <label>
          <div className="muted">Attach to client</div>
          <select className="input" value={clientId} onChange={(e)=>setClientId(e.target.value)}>
            <option value="">(none)</option>
            {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </label>
        <div style={{marginLeft:"auto",display:"flex",gap:8}}>
          <button className="btn" onClick={()=>start("google")}>Connect Google Ads</button>
          <button className="btn" onClick={()=>start("meta")}>Connect Meta Ads</button>
          <button className="btn" onClick={()=>start("linkedin")}>Connect LinkedIn Ads</button>
        </div>
      </div>

      <div style={{marginTop:20}}>
        <h3 className="h1">Quick tips</h3>
        <ul>
          <li className="muted">Google Ads requires developer token & customer ID discovery. The server will attempt discovery automatically after OAuth.</li>
          <li className="muted">Meta will ask for app permissions; use test users if necessary during development.</li>
        </ul>
      </div>
    </div>
  );
}