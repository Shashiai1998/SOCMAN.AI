import type { NextApiRequest, NextApiResponse } from "next";
import axios from "axios";
import prisma from "../../../../lib/db";
import { encrypt } from "../../../../lib/encryption";
import { discoverGoogleAccessibleCustomers } from "../../../../lib/providers/googleAds";

/**
 * OAuth callback handler for providers.
 * Exchanges code for tokens, fetches basic account info (display name / account id), and stores ConnectedAccount.
 *
 * After storing Google tokens we run discovery to populate accessible customer IDs and update the connectedAccount.meta.
 *
 * NOTE: For production, validate 'state' (CSRF) and use logged-in user session instead of passing userId in query/state.
 */

function parseState(s: any) {
  try {
    return JSON.parse(s);
  } catch {
    return {};
  }
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { provider } = req.query;
  const code = String(req.query.code || "");
  const state = req.query.state ? parseState(String(req.query.state)) : {};
  const userId = state.userId || req.query.userId || req.body.userId;

  if (!code || !userId) return res.status(400).send("Missing code or user context");

  try {
    if (provider === "google") {
      // Exchange code for tokens
      const tokenRes = await axios.post(
        "https://oauth2.googleapis.com/token",
        new URLSearchParams({
          code,
          client_id: String(process.env.GOOGLE_CLIENT_ID || ""),
          client_secret: String(process.env.GOOGLE_CLIENT_SECRET || ""),
          redirect_uri: String(process.env.GOOGLE_REDIRECT_URI || ""),
          grant_type: "authorization_code"
        }).toString(),
        { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
      );
      const data = tokenRes.data;
      // Store connected account
      const created = await prisma.connectedAccount.create({
        data: {
          provider: "google",
          providerAccountId: data.id_token || `google-${Date.now()}`,
          displayName: "Google Ads Account",
          accessTokenEnc: encrypt(data.access_token),
          refreshTokenEnc: data.refresh_token ? encrypt(data.refresh_token) : null,
          expiresAt: data.expires_in ? new Date(Date.now() + data.expires_in * 1000) : null,
          userId: String(userId)
        }
      });

      // Run discovery for accessible customers and update meta
      try {
        await discoverGoogleAccessibleCustomers(created.id);
      } catch (err) {
        console.warn("google discovery error (non-fatal):", err?.message || err);
      }

      return res.redirect("/?connected=google");
    } else if (provider === "meta") {
      // Exchange code for short-lived token
      const tokenRes = await axios.get("https://graph.facebook.com/v16.0/oauth/access_token", {
        params: {
          client_id: process.env.META_CLIENT_ID,
          redirect_uri: process.env.META_REDIRECT_URI,
          client_secret: process.env.META_CLIENT_SECRET,
          code
        }
      });
      const tokenData = tokenRes.data;
      // Exchange for long-lived token
      const longRes = await axios.get("https://graph.facebook.com/v16.0/oauth/access_token", {
        params: {
          grant_type: "fb_exchange_token",
          client_id: process.env.META_CLIENT_ID,
          client_secret: process.env.META_CLIENT_SECRET,
          fb_exchange_token: tokenData.access_token
        }
      });
      const longData = longRes.data;
      // Get basic profile to use as displayName
      const profile = await axios.get("https://graph.facebook.com/me", { params: { access_token: longData.access_token, fields: "name,id" } });
      await prisma.connectedAccount.create({
        data: {
          provider: "meta",
          providerAccountId: profile.data.id,
          displayName: profile.data.name,
          accessTokenEnc: encrypt(longData.access_token),
          refreshTokenEnc: null,
          expiresAt: null,
          userId: String(userId)
        }
      });
      return res.redirect("/?connected=meta");
    } else if (provider === "linkedin") {
      // Exchange code for access token
      const params = new URLSearchParams({
        grant_type: "authorization_code",
        code,
        redirect_uri: String(process.env.LINKEDIN_REDIRECT_URI || ""),
        client_id: String(process.env.LINKEDIN_CLIENT_ID || ""),
        client_secret: String(process.env.LINKEDIN_CLIENT_SECRET || "")
      }).toString();

      const tokenRes = await axios.post("https://www.linkedin.com/oauth/v2/accessToken", params, {
        headers: { "Content-Type": "application/x-www-form-urlencoded" }
      });
      const t = tokenRes.data;
      // Get basic profile
      const profile = await axios.get("https://api.linkedin.com/v2/me", {
        headers: { Authorization: `Bearer ${t.access_token}` }
      });
      await prisma.connectedAccount.create({
        data: {
          provider: "linkedin",
          providerAccountId: profile.data.id || `linkedin-${Date.now()}`,
          displayName: (profile.data.localizedFirstName || "") + " " + (profile.data.localizedLastName || ""),
          accessTokenEnc: encrypt(t.access_token),
          refreshTokenEnc: null, // LinkedIn tokens are often long-lived (or rotated server-side)
          expiresAt: t.expires_in ? new Date(Date.now() + t.expires_in * 1000) : null,
          userId: String(userId)
        }
      });
      return res.redirect("/?connected=linkedin");
    } else {
      return res.status(400).send("Unknown provider");
    }
  } catch (err: any) {
    console.error("oauth callback error:", err?.response?.data || err.message);
    return res.status(500).json({ error: "OAuth callback error", details: err?.response?.data || err.message });
  }
}