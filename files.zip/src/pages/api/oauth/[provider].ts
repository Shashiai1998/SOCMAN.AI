import type { NextApiRequest, NextApiResponse } from "next";
import prisma from "../../../lib/db";
import { encrypt } from "../../../lib/encryption";
import axios from "axios";

/**
 * Generic OAuth callback handler skeleton.
 * - provider path param: 'google' | 'meta' | 'linkedin'
 * - This endpoint receives the provider's authorization code and exchanges for tokens,
 *   then stores encrypted tokens in ConnectedAccount.
 *
 * NOTE: For each provider, you'll need to implement the exact token exchange & user info fetch.
 */

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { provider } = req.query;
  const { code, state } = req.query;
  const userId = req.body.userId || req.query.userId;
  if (!provider || !code) return res.status(400).json({ error: "Missing provider or code" });
  if (!userId) return res.status(401).json({ error: "Missing user context" });

  try {
    if (provider === "google") {
      // Exchange code for tokens (example)
      const tokenRes = await axios.post("https://oauth2.googleapis.com/token", null, {
        params: {
          code,
          client_id: process.env.GOOGLE_CLIENT_ID,
          client_secret: process.env.GOOGLE_CLIENT_SECRET,
          redirect_uri: `${process.env.NEXTAUTH_URL}/api/oauth/google`,
          grant_type: "authorization_code"
        }
      });
      const data = tokenRes.data;
      // fetch profile / account info as needed
      // store encrypted tokens
      await prisma.connectedAccount.create({
        data: {
          provider: "google",
          providerAccountId: data.id_token || "google-account",
          displayName: "Google Account",
          accessTokenEnc: encrypt(data.access_token),
          refreshTokenEnc: data.refresh_token ? encrypt(data.refresh_token) : null,
          expiresAt: data.expires_in ? new Date(Date.now() + data.expires_in * 1000) : null,
          userId: String(userId)
        }
      });
      return res.redirect("/?connected=google");
    } else if (provider === "meta") {
      // Meta token exchange and storage (skeleton)
      // implement similar to google but with Facebook Graph token endpoint
      return res.redirect("/?connected=meta");
    } else if (provider === "linkedin") {
      // LinkedIn token exchange
      return res.redirect("/?connected=linkedin");
    } else {
      return res.status(400).json({ error: "Unknown provider" });
    }
  } catch (err: any) {
    console.error(err?.response?.data || err.message);
    return res.status(500).json({ error: "OAuth exchange failed" });
  }
}