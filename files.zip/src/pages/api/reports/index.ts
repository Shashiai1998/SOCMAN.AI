import type { NextApiRequest, NextApiResponse } from "next";
import prisma from "../../../lib/db";

/**
 * GET /api/reports?userId=...
 * Return scheduled reports for a user.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return res.status(405).end();
  }

  const userId = String(req.query.userId || "");
  if (!userId) return res.status(400).json({ error: "userId required" });

  try {
    const schedules = await prisma.reportSchedule.findMany({
      where: { userId },
      orderBy: { nextRun: "asc" }
    });
    res.json(schedules);
  } catch (err: any) {
    console.error("GET /api/reports error", err);
    res.status(500).json({ error: "internal" });
  }
}