import type { NextApiRequest, NextApiResponse } from "next";
import prisma from "../../../lib/db";

/**
 * PATCH /api/reports/[id] - update schedule (name, frequency, recipients, enabled, filters)
 * DELETE /api/reports/[id] - delete schedule
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query;
  if (!id || typeof id !== "string") return res.status(400).json({ error: "id required" });

  if (req.method === "PATCH") {
    const { name, frequency, recipients, enabled, filters } = req.body;
    const data: any = {};
    if (name !== undefined) data.name = name;
    if (frequency !== undefined) data.frequency = frequency;
    if (recipients !== undefined) data.recipients = recipients;
    if (enabled !== undefined) data.enabled = enabled;
    if (filters !== undefined) data.filters = filters;
    try {
      const updated = await prisma.reportSchedule.update({ where: { id }, data });
      return res.json(updated);
    } catch (err: any) {
      console.error("PATCH /api/reports/[id] error", err);
      return res.status(500).json({ error: "update failed" });
    }
  } else if (req.method === "DELETE") {
    try {
      await prisma.reportSchedule.delete({ where: { id } });
      return res.status(204).end();
    } catch (err: any) {
      console.error("DELETE /api/reports/[id] error", err);
      return res.status(500).json({ error: "delete failed" });
    }
  } else {
    res.setHeader("Allow", "PATCH, DELETE");
    res.status(405).end("Method Not Allowed");
  }
}