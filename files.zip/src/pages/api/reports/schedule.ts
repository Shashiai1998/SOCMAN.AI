import type { NextApiRequest, NextApiResponse } from "next";
import prisma from "../../../lib/db";

/**
 * POST /api/reports/schedule
 * body: { userId, clientId?, name, frequency, recipients (string comma), filters }
 *
 * current simplistic: store schedule and return it. Worker will pick up enabled schedules and run them.
 */

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).end();

  const { userId, clientId, name, frequency, recipients, filters } = req.body;
  if (!userId || !name || !frequency || !recipients) return res.status(400).json({ error: "userId, name, frequency, recipients required" });

  // compute nextRun: naive - daily -> tomorrow at 09:00 UTC; weekly -> next Monday 09:00; monthly -> 1st of next month 09:00
  const now = new Date();
  let nextRun = new Date(now);
  nextRun.setUTCHours(9, 0, 0, 0);
  if (frequency === "daily") {
    nextRun.setUTCDate(nextRun.getUTCDate() + 1);
  } else if (frequency === "weekly") {
    // next Monday
    const day = nextRun.getUTCDay();
    const daysUntilMonday = (8 - day) % 7 || 7;
    nextRun.setUTCDate(nextRun.getUTCDate() + daysUntilMonday);
  } else if (frequency === "monthly") {
    nextRun.setUTCMonth(nextRun.getUTCMonth() + 1);
    nextRun.setUTCDate(1);
  } else {
    return res.status(400).json({ error: "invalid frequency" });
  }

  const schedule = await prisma.reportSchedule.create({
    data: {
      userId,
      clientId: clientId || null,
      name,
      frequency,
      nextRun,
      recipients,
      filters: filters ? filters : {}
    }
  });

  res.status(201).json(schedule);
}