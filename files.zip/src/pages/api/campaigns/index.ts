import type { NextApiRequest, NextApiResponse } from "next";
import prisma from "../../../lib/db";

/**
 * Simple campaigns endpoint supporting filters:
 * - clientId (required)
 * - status
 * - q (search in name)
 * - dateFrom, dateTo to include a latest snapshot filter (not full-time series)
 *
 * Returns campaigns with the latest snapshot joined.
 */

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { clientId, status, q, dateFrom, dateTo } = req.query;
  const where: any = {};
  if (!clientId) return res.status(400).json({ error: "clientId required" });

  where.clientId = String(clientId);
  if (status) where.status = String(status);
  if (q) where.name = { contains: String(q), mode: "insensitive" };

  const campaigns = await prisma.campaign.findMany({
    where,
    include: {
      MetricSnapshots: {
        where: dateFrom || dateTo ? {
          date: {
            gte: dateFrom ? new Date(String(dateFrom)) : undefined,
            lte: dateTo ? new Date(String(dateTo)) : undefined
          }
        } : undefined,
        orderBy: { date: "desc" },
        take: 1
      }
    },
    orderBy: { createdAt: "desc" }
  });

  // map latest snapshot to top-level for simple UI consumption
  const out = campaigns.map((c) => {
    return { ...c, latestSnapshot: c.MetricSnapshots && c.MetricSnapshots[0] ? c.MetricSnapshots[0] : null };
  });

  res.json(out);
}