import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import EmailProvider from "next-auth/providers/email";
import { PrismaAdapter } from "@next-auth/prisma-adapter";
import prisma from "../../../lib/db";

export default NextAuth({
  adapter: PrismaAdapter(prisma),
  providers: [
    // Example: email provider (configure SMTP)
    EmailProvider({
      server: process.env.EMAIL_SERVER,
      from: process.env.EMAIL_FROM
    }),
    // Add credential or OAuth providers here if you want
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" }
      },
      async authorize(credentials) {
        // Minimal example: you should implement bcrypt hash compare
        const user = await prisma.user.findUnique({ where: { email: credentials?.email } });
        if (!user) return null;
        // If you use credentials, compare passwordHash here.
        return { id: user.id, name: user.name, email: user.email };
      }
    })
  ],
  secret: process.env.NEXTAUTH_SECRET,
  session: { strategy: "database" },
  callbacks: {
    async session({ session, user }) {
      // attach user id for client
      (session as any).userId = user.id;
      return session;
    }
  }
});