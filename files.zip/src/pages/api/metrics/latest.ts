import type { NextApiRequest, NextApiResponse } from "next";
import prisma from "../../../lib/db";

/**
 * Returns latest metric snapshots (basic endpoint)
 * Add filters: date range, campaign name, provider, status, pagination.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const latest = await prisma.metricSnapshot.findMany({
    orderBy: { date: "desc" },
    take: 20,
    include: { connectedAccount: true, campaign: true }
  });
  res.json(latest);
}