import type { NextApiRequest, NextApiResponse } from "next";
import prisma from "../../../lib/db";

/**
 * PATCH /api/accounts/[id] - update connected account fields (clientId, displayName, providerAccountId)
 * DELETE /api/accounts/[id] - remove connected account
 *
 * NOTE: For production validate session ownership before allowing updates/deletes.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query;
  if (!id || typeof id !== "string") return res.status(400).json({ error: "id required" });

  if (req.method === "PATCH") {
    const { clientId, displayName, providerAccountId } = req.body;
    const data: any = {};
    if (clientId !== undefined) data.clientId = clientId || null;
    if (displayName !== undefined) data.displayName = displayName;
    if (providerAccountId !== undefined) data.providerAccountId = providerAccountId;
    try {
      const updated = await prisma.connectedAccount.update({ where: { id }, data });
      return res.json(updated);
    } catch (err: any) {
      console.error("PATCH /api/accounts/[id] error", err);
      return res.status(500).json({ error: "update failed" });
    }
  } else if (req.method === "DELETE") {
    try {
      await prisma.connectedAccount.delete({ where: { id } });
      return res.status(204).end();
    } catch (err: any) {
      console.error("DELETE /api/accounts/[id] error", err);
      return res.status(500).json({ error: "delete failed" });
    }
  } else {
    res.setHeader("Allow", "PATCH, DELETE");
    res.status(405).end("Method Not Allowed");
  }
}