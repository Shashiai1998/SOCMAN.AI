import type { NextApiRequest, NextApiResponse } from "next";
import prisma from "../../../lib/db";

/**
 * GET /api/clients?userId=...
 * POST /api/clients  { userId, name }
 *
 * In production derive user from session.
 */

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === "GET") {
    const userId = String(req.query.userId || "");
    if (!userId) return res.status(400).json({ error: "userId required" });
    const clients = await prisma.client.findMany({ where: { ownerId: userId }, orderBy: { createdAt: "desc" } });
    return res.json(clients);
  } else if (req.method === "POST") {
    const { userId, name } = req.body;
    if (!userId || !name) return res.status(400).json({ error: "userId and name required" });
    const client = await prisma.client.create({ data: { ownerId: userId, name } });
    return res.status(201).json(client);
  } else {
    res.setHeader("Allow", "GET, POST");
    res.status(405).end("Method Not Allowed");
  }
}