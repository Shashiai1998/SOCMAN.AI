import React from "react";

export default function Settings(){
  return (
    <div>
      <h2 className="h1">Settings</h2>
      <div className="card" style={{marginTop:12}}>
        <div style={{display:"grid",gap:8}}>
          <label>
            Organization name
            <input className="input" defaultValue="SocMan.ai Demo" />
          </label>
          <label>
            Default timezone
            <select className="input">
              <option>UTC</option>
              <option>America/Los_Angeles</option>
            </select>
          </label>
          <label>
            Branding color
            <input type="color" className="input" defaultValue="#1877f2" />
          </label>
          <div style={{display:"flex",justifyContent:"flex-end"}}>
            <button className="btn btn-primary">Save</button>
          </div>
        </div>
      </div>
    </div>
  );
}