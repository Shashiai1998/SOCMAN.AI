import React, { useEffect, useState } from "react";
import Link from "next/link";
import axios from "axios";
import { useSession, signIn } from "next-auth/react";

/**
 * Dashboard: session-aware. Uses session.userId to fetch user-specific endpoints.
 */
export default function Dashboard() {
  const { data: session, status } = useSession();
  const [snapshots, setSnapshots] = useState<any[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (status === "authenticated") load();
  }, [status]);

  async function load() {
    setLoading(true);
    try {
      const [sRes, aRes] = await Promise.all([
        axios.get("/api/metrics/latest").catch(() => ({ data: [] })),
        axios.get(`/api/accounts?userId=${encodeURIComponent((session as any)?.userId)}`).catch(() => ({ data: [] }))
      ]);
      setSnapshots(sRes.data || []);
      setAccounts(aRes.data || []);
    } finally { setLoading(false); }
  }

  if (status === "loading") return <div className="card">Loading session...</div>;
  if (status !== "authenticated") {
    return (
      <div className="card">
        <h2 className="h1">Welcome to SocMan.ai</h2>
        <p className="muted">Sign in to manage clients, connect ad accounts and view consolidated metrics.</p>
        <div style={{ marginTop: 12 }}>
          <button className="btn btn-primary" onClick={() => signIn()}>Sign in</button>
        </div>
      </div>
    );
  }

  const totalImpressions = snapshots.reduce((s, r) => s + (r.impressions || 0), 0);
  const totalClicks = snapshots.reduce((s, r) => s + (r.clicks || 0), 0);
  const totalSpend = snapshots.reduce((s, r) => s + ((r.spendMicros ? Number(r.spendMicros) / 1_000_000 : 0) || 0), 0);

  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
        <div>
          <h2 className="h1">Overview</h2>
          <div className="muted">Consolidated metrics across connected ad accounts</div>
        </div>
        <div>
          <Link href="/reports/builder"><a className="btn btn-ghost">Create Report</a></Link>
          <Link href="/connect"><a className="btn btn-primary" style={{marginLeft:12}}>Connect Account</a></Link>
        </div>
      </div>

      <div className="grid" style={{marginBottom:18}}>
        <div className="card">
          <div className="muted">Impressions (recent)</div>
          <div className="kpi">{totalImpressions.toLocaleString()}</div>
          <div className="muted">Across last snapshots</div>
        </div>
        <div className="card">
          <div className="muted">Clicks (recent)</div>
          <div className="kpi">{totalClicks.toLocaleString()}</div>
          <div className="muted">CTR and conversions shown on campaign pages</div>
        </div>
        <div className="card">
          <div className="muted">Spend (recent)</div>
          <div className="kpi">${totalSpend.toFixed(2)}</div>
          <div className="muted">Aggregated from connected platforms</div>
        </div>
        <div className="card">
          <div className="muted">Connected Accounts</div>
          <div style={{display:"flex",flexDirection:"column",gap:8}}>
            {accounts.length === 0 ? <div className="muted">No accounts yet</div> :
              accounts.map(a => (
                <Link key={a.id} href={`/accounts`}><a className="link">{a.provider.toUpperCase()} — {a.displayName || a.providerAccountId}</a></Link>
              ))}
          </div>
        </div>
      </div>

      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <h3 className="h1">Recent snapshots</h3>
        <div className="muted">{loading ? "Loading..." : `${snapshots.length} rows`}</div>
      </div>

      <div style={{marginTop:12}}>
        {snapshots.length === 0 ? <div className="card">No data yet — connect accounts and run the worker to pull data.</div> : (
          snapshots.map(s => (
            <div key={s.id} className="card" style={{marginBottom:10}}>
              <div style={{display:"flex",justifyContent:"space-between"}}>
                <div>
                  <div style={{fontWeight:700}}>{s.connectedAccount?.displayName || s.connectedAccountId}</div>
                  <div className="muted">{s.campaign?.name || "Account-level snapshot"}</div>
                </div>
                <div style={{textAlign:"right"}}>
                  <div style={{fontWeight:700}}>{(s.impressions || 0).toLocaleString()} imp</div>
                  <div className="muted">{(s.clicks || 0).toLocaleString()} clicks • ${(s.spendMicros ? Number(s.spendMicros)/1_000_000 : 0).toFixed(2)}</div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}