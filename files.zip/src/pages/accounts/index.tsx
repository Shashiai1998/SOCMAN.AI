import React, { useEffect, useState } from "react";
import axios from "axios";
import Link from "next/link";
import { useSession, signIn } from "next-auth/react";

export default function AccountsPage(){
  const { data: session, status } = useSession();
  const [accounts, setAccounts] = useState<any[]>([]);

  useEffect(()=>{ if (status === "authenticated") load(); }, [status]);

  async function load(){
    const res = await axios.get(`/api/accounts?userId=${encodeURIComponent((session as any)?.userId)}`).catch(()=>({data:[]}));
    setAccounts(res.data || []);
  }

  if (status === "loading") return <div className="card">Loading session...</div>;
  if (status !== "authenticated") {
    return (
      <div className="card">
        <h2 className="h1">Connected Accounts</h2>
        <p className="muted">Sign in to view connected accounts.</p>
        <button className="btn btn-primary" onClick={() => signIn()}>Sign in</button>
      </div>
    );
  }

  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <h2 className="h1">Connected Accounts</h2>
        <Link href="/connect"><a className="btn btn-ghost">Connect new</a></Link>
      </div>

      <div style={{marginTop:12}}>
        {accounts.length === 0 ? <div className="card">No connected accounts yet</div> :
          accounts.map(a=>(
            <div key={a.id} className="card" style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div>
                <div style={{fontWeight:700}}>{a.displayName || a.provider}</div>
                <div className="muted">{a.provider} • {a.providerAccountId}</div>
              </div>
              <div style={{display:"flex",gap:8}}>
                <button className="btn">View</button>
                <button className="btn btn-ghost">Edit</button>
              </div>
            </div>
          ))
        }
      </div>
    </div>
  );
}