import React, { useEffect, useState } from "react";
import axios from "axios";
import { useSession, signIn } from "next-auth/react";

export default function ReportBuilder(){
  const { data: session, status } = useSession();
  const [clients, setClients] = useState<any[]>([]);
  const [clientId, setClientId] = useState("");
  const [name, setName] = useState("Weekly Ads Summary");
  const [frequency, setFrequency] = useState("weekly");
  const [recipients, setRecipients] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  useEffect(()=>{ if (status === "authenticated") loadClients(); }, [status]);

  async function loadClients(){
    const res = await axios.get(`/api/clients?userId=${encodeURIComponent((session as any)?.userId)}`).catch(()=>({data:[]}));
    setClients(res.data||[]);
  }

  async function schedule(e: React.FormEvent){
    e.preventDefault();
    if(!recipients) return alert("recipients required");
    const filters:any = {};
    if(dateFrom) filters.dateFrom = dateFrom;
    if(dateTo) filters.dateTo = dateTo;
    await axios.post("/api/reports/schedule", {
      userId: (session as any)?.userId,
      clientId: clientId || null,
      name,
      frequency,
      recipients,
      filters
    }).catch(err=>{ console.error(err); alert("failed to schedule"); return; });
    alert("Scheduled report");
  }

  if (status === "loading") return <div className="card">Loading session...</div>;
  if (status !== "authenticated") {
    return (
      <div className="card">
        <h2 className="h1">Report Builder</h2>
        <p className="muted">Sign in to build and schedule reports.</p>
        <button className="btn btn-primary" onClick={() => signIn()}>Sign in</button>
      </div>
    );
  }

  return (
    <div>
      <h2 className="h1">Report Builder</h2>
      <div className="card" style={{marginTop:12}}>
        <form onSubmit={schedule} style={{display:"grid",gap:12}}>
          <label>
            Client
            <select className="input" value={clientId} onChange={(e)=>setClientId(e.target.value)}>
              <option value="">(All clients)</option>
              {clients.map(c=> <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </label>

          <label>
            Report Name
            <input className="input" value={name} onChange={(e)=>setName(e.target.value)} />
          </label>

          <label>
            Frequency
            <select className="input" value={frequency} onChange={(e)=>setFrequency(e.target.value)}>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
            </select>
          </label>

          <label>
            Recipients (comma separated)
            <input className="input" value={recipients} onChange={(e)=>setRecipients(e.target.value)} />
          </label>

          <div style={{display:"flex",gap:8}}>
            <label style={{flex:1}}>
              Date from
              <input type="date" className="input" value={dateFrom} onChange={(e)=>setDateFrom(e.target.value)} />
            </label>
            <label style={{flex:1}}>
              Date to
              <input type="date" className="input" value={dateTo} onChange={(e)=>setDateTo(e.target.value)} />
            </label>
          </div>

          <div style={{display:"flex",justifyContent:"flex-end"}}>
            <button className="btn btn-primary" type="submit">Schedule report</button>
          </div>
        </form>
      </div>
    </div>
  );
}