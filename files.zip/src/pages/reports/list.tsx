import React, { useEffect, useState } from "react";
import axios from "axios";
import Link from "next/link";
import { useSession, signIn } from "next-auth/react";

/**
 * Reports list page - now fetches real schedules from /api/reports
 */
export default function ReportsList() {
  const { data: session, status } = useSession();
  const [schedules, setSchedules] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (status === "authenticated") load();
  }, [status]);

  async function load() {
    setLoading(true);
    try {
      const userId = (session as any)?.userId;
      const res = await axios.get(`/api/reports?userId=${encodeURIComponent(userId)}`);
      setSchedules(res.data || []);
    } catch (err) {
      console.error("failed to load reports", err);
      setSchedules([]);
    } finally {
      setLoading(false);
    }
  }

  if (status === "loading") return <div className="card">Loading session...</div>;
  if (status !== "authenticated") {
    return (
      <div className="card">
        <h2 className="h1">Scheduled Reports</h2>
        <p className="muted">Sign in to view and manage your scheduled reports.</p>
        <button className="btn btn-primary" onClick={() => signIn()}>Sign in</button>
      </div>
    );
  }

  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <h2 className="h1">Scheduled Reports</h2>
        <Link href="/reports/builder"><a className="btn btn-ghost">Create New</a></Link>
      </div>

      <div className="card" style={{marginTop:12}}>
        {loading ? <div className="muted">Loading...</div> : null}
        {schedules.length === 0 && !loading ? <div className="muted">No scheduled reports. Use Report Builder to create one.</div> : (
          schedules.map(s => (
            <div key={s.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:"1px solid #f3f6fb"}}>
              <div>
                <div style={{fontWeight:700}}>{s.name}</div>
                <div className="muted">{s.frequency} • Next run: {new Date(s.nextRun).toLocaleString()}</div>
                <div className="muted">Recipients: {s.recipients}</div>
              </div>
              <div style={{display:"flex",gap:8}}>
                <Link href={`/reports/edit/${s.id}`}><a className="btn">Edit</a></Link>
                <button className="btn btn-ghost" onClick={async () => {
                  if (!confirm("Disable this schedule?")) return;
                  try {
                    await axios.patch(`/api/reports/${s.id}`, { enabled: false });
                    load();
                  } catch (err) { console.error(err); alert("Failed"); }
                }}>Disable</button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}