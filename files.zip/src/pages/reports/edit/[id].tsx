import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import axios from "axios";
import { useSession, signIn } from "next-auth/react";

/**
 * Edit scheduled report UI
 */
export default function ReportEdit() {
  const router = useRouter();
  const { id } = router.query as { id?: string };
  const { data: session, status } = useSession();

  const [schedule, setSchedule] = useState<any>(null);
  const [clients, setClients] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (status === "authenticated" && id) load();
  }, [status, id]);

  async function load() {
    setLoading(true);
    try {
      const userId = (session as any)?.userId;
      const [sRes, cRes] = await Promise.all([
        axios.get(`/api/reports?userId=${encodeURIComponent(userId)}`),
        axios.get(`/api/clients?userId=${encodeURIComponent(userId)}`)
      ]);
      const found = (sRes.data || []).find((r: any) => r.id === id);
      setSchedule(found || null);
      setClients(cRes.data || []);
    } catch (err) {
      console.error("load edit data", err);
    } finally {
      setLoading(false);
    }
  }

  if (status === "loading") return <div className="card">Loading session...</div>;
  if (status !== "authenticated") return (
    <div className="card">
      <h2 className="h1">Edit Report</h2>
      <p className="muted">Sign in to edit schedules.</p>
      <button className="btn btn-primary" onClick={() => signIn()}>Sign in</button>
    </div>
  );

  if (!schedule) return <div className="card">Loading schedule...</div>;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    try {
      await axios.patch(`/api/reports/${schedule.id}`, {
        name: schedule.name,
        frequency: schedule.frequency,
        recipients: schedule.recipients,
        enabled: schedule.enabled,
        filters: schedule.filters
      });
      alert("Saved");
      router.push("/reports/list");
    } catch (err) {
      console.error("save failed", err);
      alert("Save failed");
    }
  }

  async function remove() {
    if (!confirm("Delete this schedule?")) return;
    try {
      await axios.delete(`/api/reports/${schedule.id}`);
      router.push("/reports/list");
    } catch (err) {
      console.error("delete failed", err);
      alert("Delete failed");
    }
  }

  return (
    <div>
      <h2 className="h1">Edit Report</h2>
      <div className="card" style={{marginTop:12}}>
        <form onSubmit={save} style={{display:"grid",gap:12}}>
          <label>
            Report name
            <input className="input" value={schedule.name} onChange={(e)=>setSchedule({...schedule, name: e.target.value})} />
          </label>

          <label>
            Client
            <select className="input" value={schedule.clientId || ""} onChange={(e)=>setSchedule({...schedule, clientId: e.target.value || null})}>
              <option value="">(All clients)</option>
              {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </label>

          <label>
            Frequency
            <select className="input" value={schedule.frequency} onChange={(e)=>setSchedule({...schedule, frequency: e.target.value})}>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
            </select>
          </label>

          <label>
            Recipients
            <input className="input" value={schedule.recipients} onChange={(e)=>setSchedule({...schedule, recipients: e.target.value})} />
          </label>

          <label>
            Enabled
            <div style={{display:"flex",alignItems:"center",gap:8,marginTop:6}}>
              <input type="checkbox" checked={!!schedule.enabled} onChange={(e)=>setSchedule({...schedule, enabled: e.target.checked})} />
              <span className="muted">If disabled, schedule won't run</span>
            </div>
          </label>

          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div style={{display:"flex",gap:8}}>
              <button className="btn btn-primary" type="submit">Save</button>
              <button type="button" className="btn btn-ghost" onClick={remove}>Delete</button>
            </div>
            <div className="muted">Next run: {new Date(schedule.nextRun).toLocaleString()}</div>
          </div>
        </form>
      </div>
    </div>
  );
}