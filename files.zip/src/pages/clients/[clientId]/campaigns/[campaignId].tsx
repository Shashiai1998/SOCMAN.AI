import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import axios from "axios";

export default function CampaignDetail(){
  const router = useRouter();
  const { clientId, campaignId } = router.query as { clientId?: string, campaignId?: string };
  const [campaign, setCampaign] = useState<any>(null);
  const [snapshots, setSnapshots] = useState<any[]>([]);

  useEffect(()=>{ if(campaignId) load(); }, [campaignId]);

  async function load(){
    // We don't have a campaign detail endpoint in prototype; pull campaigns list and find it
    const res = await axios.get(`/api/campaigns?clientId=${encodeURIComponent(String(clientId||""))}`).catch(()=>({data:[]}));
    const found = (res.data || []).find((c:any)=>c.id === campaignId);
    setCampaign(found);
    // fetch recent snapshots for this campaign
    const snaps = await axios.get("/api/metrics/latest").catch(()=>({data:[]}));
    setSnapshots(((snaps.data || []) as any[]).filter(s=>s.campaignId === campaignId));
  }

  if(!campaign) return <div className="card">Loading...</div>;

  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between"}}>
        <div>
          <h2 className="h1">{campaign.name}</h2>
          <div className="muted">Status: {campaign.status} • Provider id: {campaign.providerCampaignId}</div>
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 300px",gap:12,marginTop:12}}>
        <div>
          <div className="card">
            <h4 className="h1">Performance (recent)</h4>
            {snapshots.length === 0 ? <div className="muted">No snapshots yet</div> : (
              <table className="table">
                <thead><tr><th>Date</th><th>Impr</th><th>Clicks</th><th>Spend</th></tr></thead>
                <tbody>
                  {snapshots.map(s=>(
                    <tr key={s.id}>
                      <td>{new Date(s.date).toLocaleString()}</td>
                      <td>{s.impressions || 0}</td>
                      <td>{s.clicks || 0}</td>
                      <td>${s.spendMicros ? (Number(s.spendMicros)/1_000_000).toFixed(2) : "0.00"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        <div>
          <div className="card">
            <h4 className="h1">Actions</h4>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              <button className="btn">Open in Provider</button>
              <button className="btn">Export CSV</button>
              <button className="btn btn-ghost">Compare</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}