import React, { useEffect, useState } from "react";
import axios from "axios";
import { useRouter } from "next/router";
import Link from "next/link";

export default function CampaignsPage(){
  const router = useRouter();
  const { clientId } = router.query as { clientId?: string };
  const [campaigns, setCampaigns] = useState<any[]>([]);
  const [status, setStatus] = useState("");
  const [q, setQ] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  useEffect(()=>{ if(clientId) load(); }, [clientId]);

  async function load(){
    const params = new URLSearchParams();
    if(clientId) params.set("clientId", String(clientId));
    if(status) params.set("status", status);
    if(q) params.set("q", q);
    if(dateFrom) params.set("dateFrom", dateFrom);
    if(dateTo) params.set("dateTo", dateTo);
    const res = await axios.get(`/api/campaigns?${params.toString()}`).catch(()=>({data:[]}));
    setCampaigns(res.data || []);
  }

  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <h2 className="h1">Campaigns</h2>
        <div>
          <Link href="/reports/builder"><a className="btn btn-ghost">Build Report</a></Link>
        </div>
      </div>

      <div className="card" style={{marginTop:12,marginBottom:12}}>
        <div style={{display:"flex",gap:8,alignItems:"center"}}>
          <select className="input" value={status} onChange={(e)=>setStatus(e.target.value)}>
            <option value="">Any status</option>
            <option value="ACTIVE">Active</option>
            <option value="PAUSED">Paused</option>
            <option value="DRAFT">Draft</option>
          </select>
          <input className="input" placeholder="Search campaign" value={q} onChange={(e)=>setQ(e.target.value)} />
          <input className="input" type="date" value={dateFrom} onChange={(e)=>setDateFrom(e.target.value)} />
          <input className="input" type="date" value={dateTo} onChange={(e)=>setDateTo(e.target.value)} />
          <button className="btn" onClick={load}>Filter</button>
        </div>
      </div>

      <div style={{display:"grid",gap:12}}>
        {campaigns.length === 0 ? <div className="card">No campaigns found</div> :
          campaigns.map(c => (
            <Link key={c.id} href={`/clients/${clientId}/campaigns/${c.id}`}><a className="card" style={{display:"block",textDecoration:"none",color:"inherit"}}>
              <div style={{display:"flex",justifyContent:"space-between"}}>
                <div>
                  <div style={{fontWeight:700}}>{c.name}</div>
                  <div className="muted">{c.providerCampaignId} • {c.status}</div>
                </div>
                <div style={{textAlign:"right"}}>
                  <div style={{fontWeight:700}}>{c.latestSnapshot ? `${c.latestSnapshot.impressions || 0} imp` : "—"}</div>
                  <div className="muted">{c.latestSnapshot ? `${c.latestSnapshot.clicks || 0} clicks` : "No data"}</div>
                </div>
              </div>
            </a></Link>
          ))
        }
      </div>
    </div>
  );
}