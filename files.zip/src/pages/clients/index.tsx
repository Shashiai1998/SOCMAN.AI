import React, { useEffect, useState } from "react";
import axios from "axios";
import Link from "next/link";
import { useSession, signIn } from "next-auth/react";

export default function ClientsPage(){
  const { data: session, status } = useSession();
  const [name, setName] = useState("");
  const [clients, setClients] = useState<any[]>([]);

  useEffect(()=>{ if (status === "authenticated") load(); }, [status]);

  async function load(){
    const res = await axios.get(`/api/clients?userId=${encodeURIComponent((session as any)?.userId)}`).catch(()=>({data:[]}));
    setClients(res.data || []);
  }

  async function create(e: React.FormEvent){
    e.preventDefault();
    if(!name) return alert("name required");
    await axios.post("/api/clients", { userId: (session as any)?.userId, name });
    setName("");
    load();
  }

  if (status === "loading") return <div className="card">Loading session...</div>;
  if (status !== "authenticated") {
    return (
      <div className="card">
        <h2 className="h1">Clients</h2>
        <p className="muted">Sign in to manage clients and attach accounts.</p>
        <button className="btn btn-primary" onClick={() => signIn()}>Sign in</button>
      </div>
    );
  }

  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <h2 className="h1">Clients</h2>
        <Link href="/connect"><a className="btn btn-ghost">Connect Accounts</a></Link>
      </div>
      <form onSubmit={create} style={{marginTop:12,marginBottom:18,display:"flex",gap:8}}>
        <input className="input" placeholder="New client name" value={name} onChange={(e)=>setName(e.target.value)} />
        <button className="btn btn-primary">Create</button>
      </form>

      <div className="grid">
        {clients.length === 0 ? <div className="card">No clients yet. Create one to organize campaigns and accounts.</div> :
          clients.map(c => (
            <div key={c.id} className="card">
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div>
                  <div style={{fontWeight:700}}>{c.name}</div>
                  <div className="muted">Created {new Date(c.createdAt).toLocaleDateString()}</div>
                </div>
                <div style={{display:"flex",flexDirection:"column",gap:8}}>
                  <Link href={`/clients/${c.id}/campaigns`}><a className="btn">View campaigns</a></Link>
                  <Link href="/connect"><a className="btn btn-ghost">Attach account</a></Link>
                </div>
              </div>
            </div>
          ))
        }
      </div>
    </div>
  );
}