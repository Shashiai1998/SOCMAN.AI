import nodemailer from "nodemailer";

/**
 * Simple email sender using NODEMAILER. Configure EMAIL_SERVER or EMAIL_USER/EMAIL_PASS/EMAIL_HOST etc.
 * - If process.env.EMAIL_SERVER is a full SMTP URL (e.g., smtp://user:pass@smtp.example.com:587) nodemailer accepts it.
 * - Fallback to using SMTP connection params if provided.
 */

export function getTransporter() {
  const url = process.env.EMAIL_SERVER;
  if (url) {
    return nodemailer.createTransport(url);
  }
  // fallback
  const host = process.env.EMAIL_HOST;
  const port = process.env.EMAIL_PORT ? Number(process.env.EMAIL_PORT) : undefined;
  const user = process.env.EMAIL_USER;
  const pass = process.env.EMAIL_PASS;
  if (!host || !port || !user) {
    throw new Error("No email transporter configured. Set EMAIL_SERVER or EMAIL_HOST/EMAIL_PORT/EMAIL_USER/EMAIL_PASS");
  }
  return nodemailer.createTransport({ host, port, auth: { user, pass } });
}

export async function sendReportEmail({ to, subject, html, attachments }: { to: string; subject: string; html?: string; attachments?: any[] }) {
  const transporter = getTransporter();
  const from = process.env.EMAIL_FROM || process.env.ADMIN_EMAIL || "noreply@example.com";
  const info = await transporter.sendMail({
    from,
    to,
    subject,
    html,
    attachments
  });
  return info;
}