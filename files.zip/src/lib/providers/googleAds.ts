import { GoogleAdsApi } from "google-ads-api";
import { decrypt } from "../lib/encryption";
import axios from "axios";
import prisma from "../lib/db";

/**
 * Google Ads helpers:
 * - exchange refresh token for access token
 * - discover accessible customers via customers:listAccessibleCustomers
 * - update connectedAccount.meta with discovered customerIds (array)
 * - format customer id with dashes: 123-456-7890
 */

async function refreshAccessToken(refreshToken: string) {
  const params = new URLSearchParams({
    client_id: String(process.env.GOOGLE_CLIENT_ID || ""),
    client_secret: String(process.env.GOOGLE_CLIENT_SECRET || ""),
    refresh_token: refreshToken,
    grant_type: "refresh_token"
  });
  const resp = await axios.post("https://oauth2.googleapis.com/token", params.toString(), {
    headers: { "Content-Type": "application/x-www-form-urlencoded" }
  });
  return resp.data.access_token as string;
}

function formatCustomerId(raw: string) {
  const digits = raw.replace(/\D/g, "");
  if (digits.length === 10) return `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
  return raw;
}

export async function discoverGoogleAccessibleCustomers(connectedAccountId: string) {
  const acc = await prisma.connectedAccount.findUnique({ where: { id: connectedAccountId } });
  if (!acc) throw new Error("connected account not found");
  if (!acc.refreshTokenEnc) throw new Error("no refresh token stored");

  const refreshToken = decrypt(acc.refreshTokenEnc);
  let accessToken: string;
  try {
    accessToken = await refreshAccessToken(refreshToken);
  } catch (err: any) {
    console.error("google refresh token failed", err?.response?.data || err.message);
    throw err;
  }

  try {
    const resp = await axios.post(
      "https://googleads.googleapis.com/v14/customers:listAccessibleCustomers",
      {},
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    // resp.data.resourceNames is an array like ["customers/1234567890", ...]
    const rns: string[] = resp.data.resourceNames || [];
    const customerIds = rns.map((rn) => {
      const m = rn.match(/customers\/(\d+)/);
      return m ? formatCustomerId(m[1]) : rn;
    });

    // Update connectedAccount.meta and set providerAccountId to first if not set
    const newMeta = { ...(acc.meta as any || {}), customerIds };
    const updateData: any = { meta: newMeta };
    if (!acc.providerAccountId && customerIds.length > 0) {
      updateData.providerAccountId = customerIds[0];
    }
    await prisma.connectedAccount.update({ where: { id: acc.id }, data: updateData });
    return customerIds;
  } catch (err: any) {
    console.error("listAccessibleCustomers failed", err?.response?.data || err.message);
    throw err;
  }
}

/**
 * Existing fetchGoogleAdsMetrics uses google-ads-api to run GAQL queries.
 * This function expects connectedAccount.meta.customerIds to be available (or providerAccountId).
 */
export async function fetchGoogleAdsMetrics(accountId: string) {
  const acc = await prisma.connectedAccount.findUnique({ where: { id: accountId } });
  if (!acc) return { ok: false, error: "account not found" };

  const refreshTokenEnc = acc.refreshTokenEnc;
  if (!refreshTokenEnc) return { ok: false, error: "no refresh token stored" };
  const refresh_token = decrypt(refreshTokenEnc);

  const client = new GoogleAdsApi({
    client_id: String(process.env.GOOGLE_CLIENT_ID),
    client_secret: String(process.env.GOOGLE_CLIENT_SECRET),
    developer_token: String(process.env.GOOGLE_DEVELOPER_TOKEN)
  });

  // determine customer id to query
  let customerIdRaw = acc.providerAccountId || (acc.meta && (acc.meta as any).customerIds && (acc.meta as any).customerIds[0]) || process.env.GOOGLE_LOGIN_CUSTOMER_ID || "";
  customerIdRaw = customerIdRaw.replace(/\D/g, "");
  if (!customerIdRaw) {
    return { ok: false, error: "No Google Ads customerId available on account. Run discovery." };
  }

  try {
    const customer = client.Customer({
      customer_id: customerIdRaw,
      refresh_token,
      login_customer_id: process.env.GOOGLE_LOGIN_CUSTOMER_ID || undefined
    });

    const query = `
      SELECT
        campaign.id,
        campaign.name,
        campaign.status,
        metrics.impressions,
        metrics.clicks,
        metrics.cost_micros
      FROM campaign
      WHERE segments.date DURING LAST_7_DAYS
      ORDER BY metrics.impressions DESC
      LIMIT 50
    `;

    const resp = await customer.query(query);
    const rows: any[] = [];
    for (const r of resp) {
      rows.push({
        campaignId: String(r.campaign?.id || ""),
        campaignName: r.campaign?.name || "",
        status: r.campaign?.status || "",
        impressions: Number(r.metrics?.impressions || 0),
        clicks: Number(r.metrics?.clicks || 0),
        spendMicros: BigInt(r.metrics?.cost_micros || 0),
        raw: r
      });
    }
    return { ok: true, rows };
  } catch (err: any) {
    console.error("google ads fetch error:", err?.response?.data || err.message);
    return { ok: false, error: err?.message || err };
  }
}