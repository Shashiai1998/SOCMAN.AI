import React from "react";
import TopNav from "./TopNav";
import Sidebar from "./Sidebar";

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="app-root">
      <TopNav />
      <div className="main-area">
        <Sidebar />
        <main className="content">{children}</main>
      </div>
    </div>
  );
};

export default Layout;