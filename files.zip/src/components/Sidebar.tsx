import Link from "next/link";
import { useRouter } from "next/router";
import React from "react";

const NavItem: React.FC<{ href: string; label: string }> = ({ href, label }) => {
  const r = useRouter();
  const active = r.pathname === href;
  return (
    <li className={`side-item ${active ? "active" : ""}`}>
      <Link href={href}><a>{label}</a></Link>
    </li>
  );
};

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <nav>
        <ul>
          <NavItem href="/" label="Dashboard" />
          <NavItem href="/clients" label="Clients" />
          <NavItem href="/connect" label="Connect" />
          <NavItem href="/accounts" label="Accounts" />
          <NavItem href="/reports/builder" label="Report Builder" />
          <NavItem href="/reports/list" label="Scheduled Reports" />
          <NavItem href="/account/settings" label="Settings" />
        </ul>
      </nav>
      <div className="sidebar-footer">
        <small className="muted">SocMan.ai • Manage ads & reports</small>
      </div>
    </aside>
  );
}