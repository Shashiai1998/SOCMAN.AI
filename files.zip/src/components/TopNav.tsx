import Link from "next/link";
import React from "react";
import { signIn, signOut, useSession } from "next-auth/react";

export default function TopNav() {
  const { data: session } = useSession();

  const initials = (() => {
    const name = (session as any)?.user?.name || (session as any)?.user?.email || "U";
    return String(name)
      .split(" ")
      .map((p: string) => p[0])
      .slice(0, 2)
      .join("")
      .toUpperCase();
  })();

  return (
    <header className="topnav">
      <div className="brand">
        <Link href="/"><a className="brand-link">SocMan.ai</a></Link>
      </div>
      <div className="topnav-actions">
        <Link href="/reports/list"><a className="btn btn-ghost">Reports</a></Link>
        <Link href="/connect"><a className="btn btn-primary">Connect Account</a></Link>

        {session ? (
          <>
            <button onClick={() => signOut()} className="avatar" title="Sign out">
              {initials}
            </button>
          </>
        ) : (
          <button onClick={() => signIn()} className="avatar" title="Sign in">
            Sign in
          </button>
        )}
      </div>
    </header>
  );
}